public class App {
    public static void main(String[] args) {
        System.out.println("This is my application which call the library I created myself by maven\n");
        UserJUnitTest.testExample();
    }
}
